Project Title:
TM4C Microcontroller Interfacing for an Automated Greenhouse Monitoring and Control System

Microcontroller:
TM4C123GH6PM

IDE:
Keil µVision

Programming Language:
Embedded C

# TM4C Microcontroller Interfacing for an Automated Greenhouse Monitoring and Control System
