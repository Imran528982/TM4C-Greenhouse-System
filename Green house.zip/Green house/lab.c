#include <stdint.h>              // Standard integer types
#include "tm4c123gh6pm.h"        // TM4C123 register definitions

/* -------------------------------------------------
 * Simple delay function (approx milliseconds)
 * Used for peripheral stabilization
 * ------------------------------------------------- */
void delayMs(int n)
{
    int i, j;
    for(i = 0; i < n; i++)
        for(j = 0; j < 3180; j++);   // ~1 ms delay @16 MHz
}

/* -------------------------------------------------
 * Initialize I2C0 module
 * Used for SHT21 / BH1750 sensors
 * ------------------------------------------------- */
void I2C0_Init(void)
{
    SYSCTL->RCGCI2C |= 0x01;     // Enable I2C0 clock
    SYSCTL->RCGCGPIO |= 0x02;    // Enable GPIOB clock
    delayMs(1);

    GPIOB->AFSEL |= 0x0C;        // Enable alternate function PB2, PB3
    GPIOB->ODR   |= 0x08;        // Open-drain on SDA (PB3)
    GPIOB->DEN   |= 0x0C;        // Digital enable
    GPIOB->PCTL  = (GPIOB->PCTL & 0xFFFF00FF) | 0x00003300;

    I2C0->MCR = 0x10;            // Enable I2C master mode
    I2C0->MTPR = 7;              // 100 kHz @16 MHz
}

/* -------------------------------------------------
 * Initialize SSI0 (SPI)
 * Used for MCP3008 ADC (soil moisture)
 * ------------------------------------------------- */
void SSI0_Init(void)
{
    SYSCTL->RCGCSSI |= 0x01;     // Enable SSI0 clock
    SYSCTL->RCGCGPIO |= 0x01;    // Enable GPIOA clock
    delayMs(1);

    GPIOA->AFSEL |= 0x3C;        // PA2-PA5 alternate function
    GPIOA->DEN   |= 0x3C;        // Digital enable
    GPIOA->DIR   |= 0x08;        // PA3 as CS output
    GPIOA->PCTL   = 0x00222200;  // SSI function select

    SSI0->CR1 = 0;               // Disable SSI for config
    SSI0->CPSR = 10;             // Clock prescaler
    SSI0->CR0 = 0x07;            // 8-bit data, SPI mode 0
    SSI0->CR1 |= 0x02;           // Enable SSI
}

/* -------------------------------------------------
 * Read analog value from MCP3008
 * channel: 0�7
 * Returns: 10-bit ADC value
 * ------------------------------------------------- */
uint16_t MCP3008_Read(uint8_t channel)
{
    uint16_t result;

    GPIOA->DATA &= ~(1<<3);      // CS LOW

    SSI0->DR = 0x01;             // Start bit
    while((SSI0->SR & 0x04) == 0);

    SSI0->DR = (0x80 | (channel << 4)); // Channel select
    while((SSI0->SR & 0x04) == 0);

    SSI0->DR = 0x00;
    while((SSI0->SR & 0x04) == 0);

    result = SSI0->DR & 0x3FF;   // 10-bit result

    GPIOA->DATA |= (1<<3);       // CS HIGH

    return result;
}

/* -------------------------------------------------
 * DC Motor control using GPIOE
 * ------------------------------------------------- */
void Motor_Init(void)
{
    SYSCTL->RCGCGPIO |= 0x10;    // Enable GPIOE
    GPIOE->DIR |= 0x03;          // PE0, PE1 output
    GPIOE->DEN |= 0x03;
}

void Motor_ON(void)
{
    GPIOE->DATA = 0x01;          // Motor ON
}

void Motor_OFF(void)
{
    GPIOE->DATA = 0x00;          // Motor OFF
}

/* -------------------------------------------------
 * Initialize PWM for SG90 Servo
 * Frequency: 50 Hz
 * ------------------------------------------------- */
void PWM_Init(void)
{
    SYSCTL->RCGCPWM |= 0x01;     // Enable PWM0
    SYSCTL->RCGCGPIO |= 0x02;    // Enable GPIOB
    delayMs(1);

    GPIOB->AFSEL |= 0x40;        // PB6 alternate function
    GPIOB->PCTL  = (GPIOB->PCTL & 0xF0FFFFFF) | 0x04000000;
    GPIOB->DEN  |= 0x40;

    PWM0->_0_CTL = 0;
    PWM0->_0_GENA = 0x8C;
    PWM0->_0_LOAD = 320000;      // 50 Hz
    PWM0->_0_CMPA = 16000;       // Neutral position
    PWM0->_0_CTL = 1;
    PWM0->ENABLE = 0x01;
}

/* -------------------------------------------------
 * Set servo position by duty value
 * ------------------------------------------------- */
void Servo_SetAngle(uint16_t duty)
{
    PWM0->_0_CMPA = duty;
}

/* -------------------------------------------------
 * Main Program
 * ------------------------------------------------- */
int main(void)
{
    uint16_t soil;

    I2C0_Init();
    SSI0_Init();
    Motor_Init();
    PWM_Init();

    while(1)
    {
        soil = MCP3008_Read(0);

        if(soil < 400)          // Dry soil
        {
            Motor_ON();         // Start pump
            Servo_SetAngle(24000);  // Open vent
        }
        else
        {
            Motor_OFF();        // Stop pump
            Servo_SetAngle(16000);  // Neutral
        }

        delayMs(500);
    }
}
